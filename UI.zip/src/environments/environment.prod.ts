export const environment = {
  production: true,
  ApiService:'http://localhost/ProjectManagerService/api/'
};
