export enum SortOrder
{

    Ascending,
    Descending,
    None
}