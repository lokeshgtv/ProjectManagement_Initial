
export  const priorityMin:number=1;

export  const priorityMax:number=30;
