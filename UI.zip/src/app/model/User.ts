export interface UserModel {
    UserId: number;
    FirstName: string;
    LastName: string;
    EmpId: number|null;
}
